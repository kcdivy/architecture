﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductQueryApi.Queues
{
    public class QueueOptions
    {
        public string ProductAddedEventQueueName { get; set; }
    }
}
